<?php
session_start();
include("php/databaseConnection.php");

if (!isset($_SESSION['user']['email'])) {
    header("Location: login.php");
    exit;
}

$email = $_SESSION['user']['email'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_funds'])) {
    $update = $conn->prepare("UPDATE userinfo SET balance = balance + 10 WHERE email = ?");
    $update->bind_param("s", $email);
    $update->execute();
    $update->close();
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

$stmt = $conn->prepare("SELECT fullname, email, balance FROM userinfo WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $user = $result->fetch_assoc();
} else {
    die("User not found.");
}

$balance = '0.00';

if (isset($_SESSION['user']['email'])) {
    $email = $_SESSION['user']['email'];
    
    $stmt = $conn->prepare("SELECT balance FROM userinfo WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->bind_result($balance);
    $stmt->fetch();
    $stmt->close();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['logout'])) {
    header("Location: index.html");
    exit;
}


$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Account Details</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<header>
        <div class="logo">Account Settings</div>
        <nav>
        <ul>
            <div class="hover">
                <li><a href="mainPage.php">Back Home</a></li>
            </div>
        </ul>
        </nav>
    </header>
    <main>
        <div class="account-info">
            <p><strong>Full Name:</strong> <?php echo htmlspecialchars($user['fullname']); ?></p>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
            <li><strong>Balance: </strong>$<?php echo htmlspecialchars(number_format($balance)); ?></li>
            <form method="POST">
                <button class="add-to-cart" type="submit" name="add_funds">Add Funds</button>
            </form>
            <form method="POST">
                <button class="add-to-cart" type="submit" name="logout">Logout</button>
            </form>


        </div>
    </main>
    <footer> <p>&copy; 2025 DigitalE Library. All rights reserved.</p> </footer>
</body>
</html>
