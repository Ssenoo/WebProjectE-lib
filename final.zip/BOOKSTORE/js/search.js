document.getElementById('search-btn').addEventListener('click', function () {
    const query = document.getElementById('search-input').value.trim();
    if (!query) return;

    fetch('searchHandler.php?q=' + encodeURIComponent(query))
        .then(response => response.json())
        .then(data => {
            const container = document.getElementById('search-results');
            container.innerHTML = '';

            if (data.length === 0) {
                container.innerHTML = '<p>No results found.</p>';
                return;
            }

            data.forEach(book => {
                console.log("isbn", book.isbn);
                const item = document.createElement('div');
                item.className = 'result-item';
            
                item.innerHTML = `
                    <img src="${book.image}" alt="Book Cover">
                    <div class="book-info">
                        <h3>${book.title}</h3>
                        <p class="author">By ${book.author}</p>
                        <p class="price">Price: $${book.price}</p>
                        <p class="isbn">ISBN: ${book.isbn}</p>
                    </div>
                `;
            
                const button = document.createElement('button');
                button.className = 'add-to-cart';
                button.textContent = 'View Book';
                button.addEventListener('click', () => {
                    window.location.href = `viewBook.php?isbn=${encodeURIComponent(book.isbn)}`;
                });
            
                item.querySelector('.book-info').appendChild(button);
                container.appendChild(item);
            });

        })
        .catch(error => {
            console.error('Error fetching search results:', error);
        });
});
