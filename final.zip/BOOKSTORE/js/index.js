document.addEventListener('DOMContentLoaded', () => {
    const searchInput = document.querySelector('.search-box input');
    const searchButton = document.querySelector('.search-box button');

    if (searchButton && searchInput) {
        searchButton.addEventListener('click', () => {
            const query = searchInput.value.trim();
            if (query) {
                window.location.href = `search.html?query=${encodeURIComponent(query)}`;
            } else {
                alert("Please enter a search term.");
            }
        });
    }
    const bookGrid = document.querySelectorAll('.book-grid')[1]; 
    if (bookGrid && bookGrid.children.length === 0) {
        books.forEach(book => {
            const bookItem = document.createElement('div');
            bookItem.classList.add('book-item');
            bookItem.innerHTML = `
                <img src="${book.image}" alt="${book.title}">
                <div class="book-info">
                    <h3>${book.title}</h3>
                    <p class="author">By ${book.author}</p>
                    <button class="add-to-cart" data-book-id="${book.id}">Add to Cart</button>
                </div>
            `;
            bookGrid.appendChild(bookItem);
        });
    }
});
