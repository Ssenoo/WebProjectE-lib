const dashboardStats = {
    totalBooks: 1241,
    newSubmissions: 12,
    pendingRequests: 8,
    activeUsers: 543
};


function populateStats() {
    const statCards = document.querySelectorAll('.stat-card p');
    statCards[0].textContent = dashboardStats.totalBooks;
    statCards[1].textContent = dashboardStats.newSubmissions;
    statCards[2].textContent = dashboardStats.pendingRequests;
    statCards[3].textContent = dashboardStats.activeUsers;
}

function populateRecentActivity() {
    const tbody = document.querySelector('.recent-activity table tbody');
    tbody.innerHTML = '';

    recentActivities.forEach(activity => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${activity.date}</td>
            <td>${activity.activity}</td>
            <td>${activity.user}</td>
        `;
        tbody.appendChild(row);
    });
}

document.addEventListener('DOMContentLoaded', () => {
    populateStats();
    populateRecentActivity();
});
