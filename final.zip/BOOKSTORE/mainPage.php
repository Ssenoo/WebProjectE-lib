<?php
    session_start();
    include("php/databaseConnection.php");

    $balance = '0.00';

    if (isset($_SESSION['user']['email'])) {
        $email = $_SESSION['user']['email'];
        
        $stmt = $conn->prepare("SELECT balance FROM userinfo WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->bind_result($balance);
        $stmt->fetch();
        $stmt->close();
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home - DigitalE Library</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<header>
    <div class="logo">DigitalE Library</div>
    <nav>
        <ul>
            <?php if (isset($_SESSION['user'])): ?>
                <li>
                    <div class="hover">
                        <a href="viewAccount.php"><em>Welcome, <?php echo htmlspecialchars($_SESSION['user']['fullName']); ?> </em></a>
                    </div>
                </li>
            <?php endif; ?>
            <li>
                <div class="hover">
                    <a href="search.php">Browse Books</a>
                </div>
            </li>
            <li>
                <div class="hover">
                    <a href="cart.php">View Cart</a>
                </div>
            </li>
            <li>
                <div class="hover">
                    Balance: $<?php echo htmlspecialchars(number_format($balance)); ?>
                </div>
            </li>
        </ul>
    </nav>
</header>

    <main>
                <section class="hero">
                    <h1>Welcome to Your Digital Library</h1>
                    <p>Access thousands of books anytime, anywhere</p>
                    </div>
                </section>

                <?php
                include("php/databaseConnection.php");

                $sql = "SELECT title, author, image, price, isbn FROM bookdata ORDER BY RAND() LIMIT 7";
                $result = mysqli_query($conn, $sql);
                ?>




        <section class="featured-books">
            <h2>Our Featured Books</h2>
            <div class="book-grid">
                <?php if (mysqli_num_rows($result) > 0): ?>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <div class="book-item">
                            <img src="<?php echo htmlspecialchars($row['image']); ?>" alt="Book Cover">
                            <div class="book-info">
                                <h3><?php echo htmlspecialchars($row['title']); ?></h3>
                                <h3>$<?php echo htmlspecialchars($row['price']); ?></h3>
                                <p class="author">By <?php echo htmlspecialchars($row['author']); ?></p>
                                <button class="add-to-cart" onclick="window.location.href='viewBook.php?isbn=<?php echo urlencode($row['isbn']); ?>'">View Book</button>

                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <p>No books found.</p>
                <?php endif; ?>
            </div>
        </section>

        
        <?php mysqli_close($conn); ?>
    </main>
    
    <footer> <p>&copy; 2025 DigitalE Library. All rights reserved.</p> </footer>
        <script src="js/cart.js"></script>
        <script src="js/index.js"></script>
</body>
</html>
