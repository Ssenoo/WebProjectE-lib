<?php
header('Content-Type: application/json');

include("php/databaseConnection.php");

$q = $_GET['q'] ?? '';
$q = trim($q);

if ($q === '') {
    echo json_encode([]);
    exit;
}

$stmt = $conn->prepare("SELECT title, author, image, price, isbn, summary FROM bookdata WHERE title LIKE ? OR author LIKE ? OR isbn LIKE ?");
$like = '%' . $q . '%';
$stmt->bind_param("sss", $like, $like, $like);
$stmt->execute();

$result = $stmt->get_result();
$books = [];

while ($row = $result->fetch_assoc()) {
    $books[] = $row;
}

echo json_encode($books);
?>
