<?php 
    session_start(); 
    include("php/databaseConnection.php");

    $balance = '0.00';

    if (isset($_SESSION['user']['email'])) {
        $email = $_SESSION['user']['email'];
        
        $stmt = $conn->prepare("SELECT balance FROM userinfo WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->bind_result($balance);
        $stmt->fetch();
        $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Search Books - DigitalE Library</title>
    <link rel="stylesheet" href="css/books.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <div class="logo">DigitalE Library</div>
        <nav>
            <ul>
                <?php if (isset($_SESSION['user'])): ?>
                    <li><a href="viewAccount.php"><em>Welcome, <?php echo htmlspecialchars($_SESSION['user']['fullName']); ?> </em></a></li>
                <?php endif; ?>
                <li><a href="mainPage.php">Home</a></li>
                <li><a href="cart.php">View Cart</a></li>
                <li>Balance: $<?php echo htmlspecialchars(number_format($balance)); ?></li>
            </ul>
        </nav>
    </header>

    <main class="search-page">
        <div class="search-container">
            <h1>Find Your Next Read</h1>
            <div class="search-box">
                <input type="text" id="search-input" placeholder="Search by title, author, or ISBN...">
                <button id="search-btn">Search</button>
            </div>
            <div class="search-results" id="search-results">
            </div>
        </div>
    </main>

    <footer>
        <p>&copy; 2025 DigitalE Library. All rights reserved.</p>
    </footer>
    <script src="js/search.js"></script>
</body>
</html>
