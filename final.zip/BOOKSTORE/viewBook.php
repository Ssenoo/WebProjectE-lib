<?php
session_start();
include("php/databaseConnection.php");

if (!isset($_GET['isbn'])) {
    echo "No book selected.";
    exit;
}

$balance = '0.00';

if (isset($_SESSION['user']['email'])) {
    $email = $_SESSION['user']['email'];
    
    $stmt = $conn->prepare("SELECT balance FROM userinfo WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->bind_result($balance);
    $stmt->fetch();
    $stmt->close();
}

$isbn = $_GET['isbn'];
$stmt = $conn->prepare("SELECT title, author, image, price, isbn, summary FROM bookdata WHERE isbn = ?");
$stmt->bind_param("s", $isbn);
$stmt->execute();
$result = $stmt->get_result();
$book = $result->fetch_assoc();

if (!$book) {
    echo "Book not found.";
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo htmlspecialchars($book['title']); ?> - Book Details</title>
    <link rel="stylesheet" href="css/style.css">

    <header>
        <div class="logo">DigitalE Library</div>
        <nav>
        <ul>
            <?php if (isset($_SESSION['user'])): ?>
                <li><a href="viewAccount.php"><em>Welcome, <?php echo htmlspecialchars($_SESSION['user']['fullName']); ?> </em></a></li>
            <?php endif; ?>
            <li><a href="search.php">Browse Books</a></li>
            <li><a href="cart.php">View Cart</a></li>
            <li>Balance: $<?php echo htmlspecialchars(number_format($balance)); ?></li>
        </ul>
    </nav>
    </header>

    <style>
        .book-detail-container {
            display: flex;
            gap: 2rem;
            padding: 2rem;
            max-width: 900px;
            margin: auto;
        }

        .book-detail-container img {
            width: 300px;
            height: auto;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .book-detail-info {
            flex: 1;
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }

        .book-detail-info h1 {
            font-size: 2rem;
            margin-bottom: 0.5rem;
        }

        .book-detail-info p {
            font-size: 1rem;
            line-height: 1.6;
        }

        .book-meta {
            color: #555;
        }

        .price {
            font-size: 1.5rem;
            font-weight: bold;
            color: #1a73e8;
        }

        .back-link {
            display: inline-block;
            margin: 1rem 2rem;
            text-decoration: none;
            color: #1a73e8;
            font-weight: bold;
        }

        .back-link:hover {
            text-decoration: underline;
        }
        .add-to-cart {
        background-color: #28a745;
        color: white;
        border: none;
        padding: 0.5rem 1rem;
        border-radius: 4px;
        cursor: pointer;
        font-size: 0.9rem;
        transition: background-color 0.2s;
        margin-top: 0.5rem;
        }

        .add-to-cart:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
    <div class="book-detail-container">
        <img src="<?php echo htmlspecialchars($book['image']); ?>" alt="Book Cover">
        <div class="book-detail-info">
            <h1><?php echo htmlspecialchars($book['title']); ?></h1>
            <p class="book-meta">By <?php echo htmlspecialchars($book['author']); ?></p>
            <p class="book-meta">ISBN: <?php echo htmlspecialchars($book['isbn']); ?></p>
            <p class="price">$<?php echo number_format($book['price'], 2); ?></p>
            <p><?php echo nl2br(htmlspecialchars($book['summary'])); ?></p>
            <form method="POST" action="addCart.php">
            <input type="hidden" name="isbn" value="<?php echo htmlspecialchars($book['isbn']); ?>">
            <button type="submit" class="add-to-cart">Add to Cart</button>
            </form>


        </div>
    </div>
    <footer> <p>&copy; 2025 DigitalE Library. All rights reserved.</p> </footer>
</body>
</html>
