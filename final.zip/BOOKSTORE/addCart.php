<?php
session_start();
include("php/databaseConnection.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $isbn = $_POST['isbn'] ?? null;

    if (!$isbn) {
        http_response_code(400);
        echo "Missing book ID.";
        exit;
    }

    $stmt = $conn->prepare("SELECT title, author, image, price FROM bookdata WHERE isbn = ?");
    $stmt->bind_param("s", $isbn);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($book = $result->fetch_assoc()) {
        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }

        if (isset($_SESSION['cart'][$isbn])) {
            $_SESSION['cart'][$isbn]['quantity'] = 1;
        } else {
            $_SESSION['cart'][$isbn] = [
                'title' => $book['title'],
                'author' => $book['author'],
                'image' => $book['image'],
                'price' => $book['price'],
                'quantity' => 1
            ];
        }

        header("Location: http://localhost/BOOKSTORE/mainPage.php"); 
    } else {
        http_response_code(404);
        echo "Book not found.";
    }

    $stmt->close();
    $conn->close();
}
