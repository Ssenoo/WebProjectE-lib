<?php
include("databaseConnection.php");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $user = trim($_POST['email']);

    if (empty($user)) {
        echo '<script>
        alert("Email required.");
        window.location.href = "../admin-users.html";
        </script>';
exit;
        exit;
    }

    $sql = "DELETE FROM userinfo WHERE email = ?";
    $stmt = mysqli_prepare($conn, $sql);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "s", $user);
        mysqli_stmt_execute($stmt);

        if (mysqli_stmt_affected_rows($stmt) > 0) {
            echo '<script>
            alert("User removed successfully.");
            window.location.href = "../admin-users.html";
            </script>';
    exit;
            header("Location: http://localhost/BOOKSTORE/admin.html");
        } else {
            echo '<script>
                    alert("No user found with that email.");
                    window.location.href = "../admin-users.html";
                    </script>';
            exit;
        }
        mysqli_stmt_close($stmt);
    } else {
        echo "Database error: " . mysqli_error($conn);
    }

    mysqli_close($conn);
} else {
    echo "Invalid request.";
}
