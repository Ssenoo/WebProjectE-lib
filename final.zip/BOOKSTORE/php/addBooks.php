<?php
include("databaseConnection.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $author = $_POST['author'];
    $image = $_POST['image'];
    $price = $_POST['price'];
    $sum = $_POST['summary'];
    $isbn = $_POST['isbn'];

    if (empty($title) || empty($author) || empty($image) || empty($price) || empty($sum) || empty($isbn)) {
        echo '<script>
        alert("All fields are required.");
        window.location.href = "../admin-books.html";
        </script>';
        exit;
        exit;
    }

    $stmt = $conn->prepare("INSERT INTO bookdata (title, author, image, price, summary, isbn) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $title, $author, $image, $price, $sum, $isbn);

    if ($stmt->execute()) {
        $stmt->close();
        $conn->close();
        header("Location: http://localhost/BOOKSTORE/admin.html"); 
        exit;
    } else {
        echo "Error: " . $stmt->error;
    }
} else {
    echo '<script>
    alert("Invalid request.");
    window.location.href = "../admin-books.html";
    </script>';
    exit;
}
?>
