<?php
session_start(); 
include("databaseConnection.php");
if ($_SERVER["REQUEST_METHOD"] == "POST") 
{
    $email = $_POST['login-email'];
    $password = $_POST['login-password'];

    if (empty($email) || empty($password)) 
    {
        echo '<script>
        alert("Email and password are required.");
        window.location.href = "../index.html";
        </script>';
exit;
        exit;
    }

    $sql = "SELECT * FROM userinfo WHERE email = '$email'";
    $result = mysqli_query($conn, $sql);

    if ($result && mysqli_num_rows($result) === 1) 
    {
        $row = mysqli_fetch_assoc($result);

        if ($row['email'] == "ADMIN@gmail.com" && $row['password'] === "admin123")
        {
            header("Location: http://localhost/BOOKSTORE/admin.html");
            exit;
        }

        if ($row['password'] === $password) 
        {
            $_SESSION['user'] = $row;
            header("Location: http://localhost/BOOKSTORE/mainPage.php");
            exit;
        } 
        else 
        {
            echo '<script>
            alert("Incorrect Password.");
            window.location.href = "../index.html";
            </script>';
    exit;
        }
    } 
    else 
    {
        echo '<script>
        alert("Account does not exist.");
        window.location.href = "../index.html";
        </script>';
exit;
    }
    mysqli_close($conn);
} 
else 
{
    echo "Invalid request.";
}
?>