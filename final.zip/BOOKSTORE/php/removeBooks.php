<?php
include("databaseConnection.php");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $isbn = trim($_POST['isbn']);

    if (empty($isbn)) {
        echo '<script>
        alert("ISBN required.");
        window.location.href = "../admin-books.html";
        </script>';
        exit;
    }

    $sql = "DELETE FROM bookdata WHERE isbn = ?";
    $stmt = mysqli_prepare($conn, $sql);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "s", $isbn);
        mysqli_stmt_execute($stmt);

        if (mysqli_stmt_affected_rows($stmt) > 0) {
            echo '<script>
            alert("Book removed successfully.");
            window.location.href = "../admin-books.html";
            </script>';
            exit;
            header("Location: http://localhost/BOOKSTORE/admin.html");

        } else {
            echo '<script>
            alert("No book found with that ISBN.");
            window.location.href = "../admin-books.html";
            </script>';
    exit;
        }

        mysqli_stmt_close($stmt);
    } else {
        echo "Database error: " . mysqli_error($conn);
    }

    mysqli_close($conn);
} else {
    echo "Invalid request.";
}
