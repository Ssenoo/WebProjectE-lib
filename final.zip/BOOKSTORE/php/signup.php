<?php
include("databaseConnection.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fullName = trim($_POST['fullName']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirmPassword'];

    if (empty($fullName) || empty($email) || empty($password) || empty($confirmPassword)) {
        echo '<script>
        alert("All fields are required.");
        window.location.href = "../signup.html";
        </script>';
exit;
        exit;
    }

    if ($password !== $confirmPassword) {
        echo '<script>
        alert("Passwords do not match.");
        window.location.href = "../signup.html";
        </script>';
exit;
        exit;
    }

    $checkSql = "SELECT email FROM userinfo WHERE email = ?";
    $stmt = mysqli_prepare($conn, $checkSql);
    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);

    if (mysqli_stmt_num_rows($stmt) > 0) {
        echo '<script>
        alert("Email already exists.");
        window.location.href = "../signup.html";
        </script>';
exit;
        mysqli_stmt_close($stmt);
        mysqli_close($conn);
        exit;
    }
    mysqli_stmt_close($stmt);

    $insertSql = "INSERT INTO userinfo (fullName, email, password) VALUES (?, ?, ?)";
    $insertStmt = mysqli_prepare($conn, $insertSql);
    mysqli_stmt_bind_param($insertStmt, "sss", $fullName, $email, $password);

    if (mysqli_stmt_execute($insertStmt)) {
        mysqli_stmt_close($insertStmt);
        mysqli_close($conn);
        header("Location: http://localhost/BOOKSTORE/index.html");
        exit;
    } else {
        echo "Error: " . mysqli_error($conn);
    }
} else {

    echo '<script>
    alert("Invalid request.");
    window.location.href = "../admin-books.html";
    </script>';
exit;
}
