<?php
include("databaseConnection.php");

$sql = "SELECT title, author, image, isbn FROM bookdata";
$result = mysqli_query($conn, $sql);
?>

<section class="featured-books">
    <h2>Featured Books</h2>
    <div class="book-grid">
        <?php if (mysqli_num_rows($result) > 0): ?>
            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                <div class="book-item">
                    <img src="<?php echo htmlspecialchars($row['image']); ?>" alt="Book Cover">
                    <div class="book-info">
                        <h3><?php echo htmlspecialchars($row['title']); ?></h3>
                        <p class="author">By <?php echo htmlspecialchars($row['author']); ?></p>
                        <button class="add-to-cart" data-book-id="<?php echo htmlspecialchars($row['isbn']); ?>">View Book</button>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p>No books found.</p>
        <?php endif; ?>
    </div>
</section>

<?php mysqli_close($conn); ?>
