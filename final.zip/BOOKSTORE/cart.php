<?php
session_start();
$cart = $_SESSION['cart'] ?? [];
include("php/databaseConnection.php");

$balance = '0.00';

if (isset($_SESSION['user']['email'])) {
    $email = $_SESSION['user']['email'];
    
    $stmt = $conn->prepare("SELECT balance FROM userinfo WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->bind_result($balance);
    $stmt->fetch();
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Cart - DigitalE Library</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/cart.css">
</head>
<body>
    <header>
        <div class="logo">DigitalE Library</div>
        <nav>
            <ul>
            <?php if (isset($_SESSION['user'])): ?>
                <li><a href="viewAccount.php"><em>Welcome, <?php echo htmlspecialchars($_SESSION['user']['fullName']); ?> </em></a></li>
            <?php endif; ?>
                <li><a href="mainPage.php">Home</a></li>
                <li><a href="search.php">Browse Books</a></li>
                <li>Balance: $<?php echo htmlspecialchars(number_format($balance)); ?></li>
                </ul>
        </nav>
    </header>
    
    <main class="cart-page">
        <h1>Your Cart</h1>
        
        <div class="cart-container">
            <div class="cart-items">
                <?php if (empty($cart)): ?>
                    <p>Your cart is empty.</p>
                <?php else: ?>
                    <?php 
                    $subtotal = 0;
                    foreach ($cart as $isbn => $book): 
                        $itemTotal = $book['price'];
                        $subtotal += $itemTotal;
                    ?>
                        <div class="cart-item">
                            <img src="<?php echo htmlspecialchars($book['image']); ?>" alt="Book Cover">
                            <div class="item-details">
                                <h3><?php echo htmlspecialchars($book['title']); ?></h3>
                                <p class="author">By <?php echo htmlspecialchars($book['author']); ?></p>
                                                        
                        <button class="remove-item" data-isbn="<?php echo htmlspecialchars($isbn); ?>">Remove item</button>
                            </div>
                            <div class="item-price">$<?php echo number_format($itemTotal, 2); ?></div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            
            
            <div class="cart-summary">
                <h2>Order Summary</h2>
                <?php if (!empty($cart)): ?>
                    <div class="summary-details">
                        <div class="summary-row">
                            <span>Subtotal</span>
                            <span>$<?php echo number_format($subtotal); ?></span>
                        </div>
                        <div class="summary-row total">
                            <span>Total</span>
                            <span>$<?php echo number_format($subtotal); ?></span>
                        </div>
                    </div>
                    
                    <!-- <div class="payment-options">
                       
                        <div id="online-payment-form" class="payment-form">
                            <div class="form-group">
                                <label for="card-number">Card Number</label>
                                <input type="text" id="card-number" placeholder="1234 5678 9012 3456">
                            </div>
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="expiry-date">Expiry Date</label>
                                    <input type="text" id="expiry-date" placeholder="MM/YY">
                                </div>
                                <div class="form-group">
                                    <label for="cvv">CVV</label>
                                    <input type="text" id="cvv" placeholder="123">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="card-name">Name on Card</label>
                                <input type="text" id="card-name" placeholder="John Doe">
                            </div>
                        </div> -->
                        
                        <button class="checkout-btn">Proceed to Checkout</button>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>
    
    <footer>
        <p>&copy; 2025 DigitalE Library. All rights reserved.</p>
    </footer>
    
    <script src="js/cart.js"></script>
</body>
</html>
