<?php
session_start();
include("php/databaseConnection.php");

if (!isset($_SESSION['user']['email'])) {
    echo json_encode(['success' => false, 'message' => 'Not logged in.']);
    exit;
}

$email = $_SESSION['user']['email'];
$cart = $_SESSION['cart'] ?? [];

if (empty($cart)) {
    echo json_encode(['success' => false, 'message' => 'Cart is empty.']);
    exit;
}

$total = 0;
foreach ($cart as $book) {
    $total += $book['price'] * $book['quantity'];
}

$stmt = $conn->prepare("SELECT balance FROM userinfo WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->bind_result($balance);
$stmt->fetch();
$stmt->close();

if ($balance < $total) {
    echo json_encode(['success' => false, 'message' => 'Insufficient balance.']);
    exit;
}

$newBalance = $balance - $total;

$updateStmt = $conn->prepare("UPDATE userinfo SET balance = ? WHERE email = ?");
$updateStmt->bind_param("ds", $newBalance, $email);
$updateStmt->execute();
$updateStmt->close();

unset($_SESSION['cart']);

echo json_encode(['success' => true, 'message' => 'Checkout successful.']);
