<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $isbn = $_POST['isbn'] ?? null;

    if ($isbn && isset($_SESSION['cart'][$isbn])) {
        if ($_SESSION['cart'][$isbn]['quantity'] > 1) {
            $_SESSION['cart'][$isbn]['quantity'] -= 1;
        } else {
            unset($_SESSION['cart'][$isbn]);
        }

        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Invalid ISBN or item not found.']);
    }
    exit;
}
